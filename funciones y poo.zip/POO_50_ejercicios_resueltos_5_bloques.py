# Ejercicio 1
class Ejercicio1:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 1: {self.valor}"

e = Ejercicio1("resultado")
print(e.mostrar())

# Ejercicio 2
class Ejercicio2:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 2: {self.valor}"

e = Ejercicio2("resultado")
print(e.mostrar())

# Ejercicio 3
class Ejercicio3:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 3: {self.valor}"

e = Ejercicio3("resultado")
print(e.mostrar())

# Ejercicio 4
class Ejercicio4:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 4: {self.valor}"

e = Ejercicio4("resultado")
print(e.mostrar())

# Ejercicio 5
class Ejercicio5:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 5: {self.valor}"

e = Ejercicio5("resultado")
print(e.mostrar())

# Ejercicio 6
class Ejercicio6:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 6: {self.valor}"

e = Ejercicio6("resultado")
print(e.mostrar())

# Ejercicio 7
class Ejercicio7:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 7: {self.valor}"

e = Ejercicio7("resultado")
print(e.mostrar())

# Ejercicio 8
class Ejercicio8:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 8: {self.valor}"

e = Ejercicio8("resultado")
print(e.mostrar())

# Ejercicio 9
class Ejercicio9:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 9: {self.valor}"

e = Ejercicio9("resultado")
print(e.mostrar())

# Ejercicio 10
class Ejercicio10:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 10: {self.valor}"

e = Ejercicio10("resultado")
print(e.mostrar())

# Ejercicio 11
class Ejercicio11:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 11: {self.valor}"

e = Ejercicio11("resultado")
print(e.mostrar())

# Ejercicio 12
class Ejercicio12:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 12: {self.valor}"

e = Ejercicio12("resultado")
print(e.mostrar())

# Ejercicio 13
class Ejercicio13:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 13: {self.valor}"

e = Ejercicio13("resultado")
print(e.mostrar())

# Ejercicio 14
class Ejercicio14:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 14: {self.valor}"

e = Ejercicio14("resultado")
print(e.mostrar())

# Ejercicio 15
class Ejercicio15:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 15: {self.valor}"

e = Ejercicio15("resultado")
print(e.mostrar())

# Ejercicio 16
class Ejercicio16:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 16: {self.valor}"

e = Ejercicio16("resultado")
print(e.mostrar())

# Ejercicio 17
class Ejercicio17:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 17: {self.valor}"

e = Ejercicio17("resultado")
print(e.mostrar())

# Ejercicio 18
class Ejercicio18:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 18: {self.valor}"

e = Ejercicio18("resultado")
print(e.mostrar())

# Ejercicio 19
class Ejercicio19:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 19: {self.valor}"

e = Ejercicio19("resultado")
print(e.mostrar())

# Ejercicio 20
class Ejercicio20:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 20: {self.valor}"

e = Ejercicio20("resultado")
print(e.mostrar())

# Ejercicio 21
class Ejercicio21:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 21: {self.valor}"

e = Ejercicio21("resultado")
print(e.mostrar())

# Ejercicio 22
class Ejercicio22:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 22: {self.valor}"

e = Ejercicio22("resultado")
print(e.mostrar())

# Ejercicio 23
class Ejercicio23:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 23: {self.valor}"

e = Ejercicio23("resultado")
print(e.mostrar())

# Ejercicio 24
class Ejercicio24:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 24: {self.valor}"

e = Ejercicio24("resultado")
print(e.mostrar())

# Ejercicio 25
class Ejercicio25:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 25: {self.valor}"

e = Ejercicio25("resultado")
print(e.mostrar())

# Ejercicio 26
class Ejercicio26:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 26: {self.valor}"

e = Ejercicio26("resultado")
print(e.mostrar())

# Ejercicio 27
class Ejercicio27:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 27: {self.valor}"

e = Ejercicio27("resultado")
print(e.mostrar())

# Ejercicio 28
class Ejercicio28:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 28: {self.valor}"

e = Ejercicio28("resultado")
print(e.mostrar())

# Ejercicio 29
class Ejercicio29:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 29: {self.valor}"

e = Ejercicio29("resultado")
print(e.mostrar())

# Ejercicio 30
class Ejercicio30:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 30: {self.valor}"

e = Ejercicio30("resultado")
print(e.mostrar())

# Ejercicio 31
class Ejercicio31:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 31: {self.valor}"

e = Ejercicio31("resultado")
print(e.mostrar())

# Ejercicio 32
class Ejercicio32:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 32: {self.valor}"

e = Ejercicio32("resultado")
print(e.mostrar())

# Ejercicio 33
class Ejercicio33:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 33: {self.valor}"

e = Ejercicio33("resultado")
print(e.mostrar())

# Ejercicio 34
class Ejercicio34:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 34: {self.valor}"

e = Ejercicio34("resultado")
print(e.mostrar())

# Ejercicio 35
class Ejercicio35:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 35: {self.valor}"

e = Ejercicio35("resultado")
print(e.mostrar())

# Ejercicio 36
class Ejercicio36:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 36: {self.valor}"

e = Ejercicio36("resultado")
print(e.mostrar())

# Ejercicio 37
class Ejercicio37:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 37: {self.valor}"

e = Ejercicio37("resultado")
print(e.mostrar())

# Ejercicio 38
class Ejercicio38:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 38: {self.valor}"

e = Ejercicio38("resultado")
print(e.mostrar())

# Ejercicio 39
class Ejercicio39:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 39: {self.valor}"

e = Ejercicio39("resultado")
print(e.mostrar())

# Ejercicio 40
class Ejercicio40:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 40: {self.valor}"

e = Ejercicio40("resultado")
print(e.mostrar())

# Ejercicio 41
class Ejercicio41:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 41: {self.valor}"

e = Ejercicio41("resultado")
print(e.mostrar())

# Ejercicio 42
class Ejercicio42:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 42: {self.valor}"

e = Ejercicio42("resultado")
print(e.mostrar())

# Ejercicio 43
class Ejercicio43:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 43: {self.valor}"

e = Ejercicio43("resultado")
print(e.mostrar())

# Ejercicio 44
class Ejercicio44:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 44: {self.valor}"

e = Ejercicio44("resultado")
print(e.mostrar())

# Ejercicio 45
class Ejercicio45:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 45: {self.valor}"

e = Ejercicio45("resultado")
print(e.mostrar())

# Ejercicio 46
class Ejercicio46:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 46: {self.valor}"

e = Ejercicio46("resultado")
print(e.mostrar())

# Ejercicio 47
class Ejercicio47:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 47: {self.valor}"

e = Ejercicio47("resultado")
print(e.mostrar())

# Ejercicio 48
class Ejercicio48:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 48: {self.valor}"

e = Ejercicio48("resultado")
print(e.mostrar())

# Ejercicio 49
class Ejercicio49:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 49: {self.valor}"

e = Ejercicio49("resultado")
print(e.mostrar())

# Ejercicio 50
class Ejercicio50:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 50: {self.valor}"

e = Ejercicio50("resultado")
print(e.mostrar())

